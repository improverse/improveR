unlink("HAMDTL17_by_day.png")
file.copy("chapter15_example_cleaned.rds","HAMDTL17_by_day.png")
file.copy("chapter15_example_cleaned.rds","HAMDTL17_by_week_therapy.png")
file.copy("chapter15_example_cleaned.rds","EDA_table.html")


