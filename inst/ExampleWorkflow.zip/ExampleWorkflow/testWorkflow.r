unlink("./testWorkflow.html")



setupRepoDemo02 <- function() {
  Sys.setenv(IMPROVER_STEP="repo_name_todo:AT-3")
  Sys.setenv(IMPROVER_REPO_URL="https://repo-a.demo02.scintecodev.com:8443/repository")
  Sys.setenv(IMPROVER_USER="admin")
  Sys.setenv(IMPROVER_PASSWORD="sciAD1040")
  Sys.setenv(IMPROVER_TOKEN="")
  
  assign("RUNSERVERNAME","demo02",envir = globalenv())
  assign("RUNSERVERTOOL","improveRbatch",envir = globalenv())
  assign("NONMEMTOOL","Nonmem7.5",envir = globalenv())
  
}

setupRepo35 <- function() {
  Sys.setenv(IMPROVER_STEP="repo_name_todo:FO-285")
  Sys.setenv(IMPROVER_REPO_URL="https://repo-a.env35.scintecodev.com:8443/repository")
  Sys.setenv(IMPROVER_USER="admin")
  Sys.setenv(IMPROVER_PASSWORD="sciAD1040")
  Sys.setenv(IMPROVER_TOKEN="")
  
  assign("RUNSERVERNAME","run-a.env35",envir = globalenv())
  assign("RUNSERVERTOOL","3.6",envir = globalenv())
  assign("NONMEMTOOL","7.4",envir = globalenv())
  
}

#setupRepoDemo02()
setupRepo35()


rmarkdown::render("testWorkflow.Rmd")



