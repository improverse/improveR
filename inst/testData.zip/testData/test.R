testSourcedR <- function() {
  return("I was created by a function")
}